public class App {
    public static void main(String[] args) {
        final int MAX_SCORE = 100;

        int score = 85;
        System.out.println("MAX_SCORE: " + MAX_SCORE);
        System.out.println("score: " + score);
    }
}
