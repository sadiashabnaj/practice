public class App{
    public static void main(String[] args) {
        int age                 =   30;
        double temperature      =   4.5;
        Character initial       =   's';

        System.out.println(age);
        System.out.println(temperature);
        System.out.println(initial);
    }
}