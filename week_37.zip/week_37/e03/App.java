public class App{
    public static void main(){
        int a      = 5;
        int b      = 3;
        System.out.println(a + b);
        System.out.println(a - b);
        System.out.println(a / b);
        System.out.println(a * b);
    }
}