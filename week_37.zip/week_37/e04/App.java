public class App{
    public static void main(String[] args) {
        int num             = 5;
        double decimal      = 2.5;
        double sum          = num + decimal;

        System.out.println(sum);

        int casted          = (int) sum;
        System.out.println(casted);


    }
}